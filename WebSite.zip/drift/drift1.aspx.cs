﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class drift_drift1 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void TextBox1_TextChanged(object sender, EventArgs e)
    {
    int Number= Convert.ToInt32(Session["Number1"]);

   DataSet dt = SqlHelper.ExecuteDataset(CommandType.Text, "SELECT * FROM drift WHERE Number ='" + Number + "' ");

   if (dt.Tables[0].Rows.Count != Number)
       {
       Response.Write("<script>alert('编号已失效，请重新输入。')</script>");
       Response.Redirect("drift.aspx");
       return;
       }
    }



    protected void Button1_Click(object sender, EventArgs e)
    {   
        int Number= Convert.ToInt32(Session["Number1"]);
        int Message = Convert.ToInt32(TextBox1.Text);
        SqlHelper.ExecuteNonQuery(CommandType.Text, "UPDATE [chang].[dbo].[login] SET [Message] = '" + Message + "' WHERE Number='" + Number  + "'");
        Response.Write("<script>alert('感谢您的留言，欢迎您再次使用漂流伞。')</script>");
        Session["Number1"] = null;

    }
}