﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class drift : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Button1_Click(object sender, EventArgs e)
    {
        int Number = Convert.ToInt32(TextBox1 .Text );
        Session["Number1"] = Number;

        DataSet dt = SqlHelper.ExecuteDataset(CommandType.Text, "SELECT * FROM drift WHERE Number ='" + Number + "' ");
        if (dt.Tables[0].Rows.Count == 1)
        {
            Response.Write("<script>alert('您是第'" + Number + "'位同学。')</script>");
            
            Response.Redirect("drift1.aspx");
        }
        else
        {

            Response.Write("<script>alert('编号错误，请核对。')</script>");
            return;

        }

    }
}